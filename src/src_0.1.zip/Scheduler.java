import static java.lang.Math.abs;
import static java.lang.Math.decrementExact;

public class Scheduler extends Dispatcher implements IF
{

    public Scheduler(RequestsQueue RQ)
    {
        super(RQ);
    }

    @Override
    public void schedule()
    {
        if (!requestsQueue.isEmpty())
            info = requestsQueue.pop();
        int pickCounter = 0;
        int sameFloorPickCounter = 0;
        while(!requestsQueue.isEmpty())
        {
            requestIndex = info[0];
            requestType = info[1];
            requestFloor = info[2];
            requestTime = info[3];
            requestFlag = info[4];

//            System.out.println("# "+requestIndex);

            if(requestFlag == 0)
            // 有效 未执行
            {
                if(requestFloor == currentFloor)
                // 目标楼层和现楼层相同 STILL
                {
                    timer = timer > requestTime ? timer : requestTime;
                    timer += 1;
                    this.toString(requestIndex, 0);
                    int scanCounter = (int)requestIndex+1;
                    this.sameJudger(scanCounter);
                }
                else
                // 目标楼层和现楼层不同
                {
                    timer = timer > requestTime ? timer : requestTime;
                    double endTime = abs(currentFloor - requestFloor)*0.5 + timer;
                    int direction = (requestFloor - currentFloor) > 0 ? 1 : 2; // 1: UP 2: DOWN
                    int scanCounter = (int)requestIndex+1;
                    while(!requestsQueue.isEmpty(scanCounter))
                    {
                        if ( getRequestQueueTime(scanCounter) > endTime+1)
                            break;
                        else if (getRequestQueueTime(scanCounter) > endTime)
                        {
                            sameJudger((int)requestIndex, scanCounter);
                        }
                        else
                        {
                            if ( !sameJudger((int)requestIndex, scanCounter) )
                            {
                                if (direction == 1) //UP
                                {
                                    if (getRequestQueueType(scanCounter) == 1 )
                                    {
                                        if (currentFloor < getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) < requestFloor)
                                        {
                                            if ((getRequestQueueFloor(scanCounter) - currentFloor) * 0.5 + timer > getRequestQueueTime(scanCounter))
                                            {
                                                endTime += identifier(scanCounter);
                                            }
                                        }
                                        else if (getRequestQueueFloor(scanCounter) == requestFloor)
                                        {
                                                requestsQueue.setSameFloor(scanCounter);
                                                sameFloorPickCounter += 1;
                                        }
                                    }
                                    else if (getRequestQueueType(scanCounter) == 0)
                                    {
                                        if (currentFloor < getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) < requestFloor)
                                        {
                                            if ( (getRequestQueueFloor(scanCounter) - currentFloor)*0.5+timer > getRequestQueueTime(scanCounter) )
                                            {
                                                endTime += identifier(scanCounter);
                                            }
                                        }
                                        else if (requestFloor == getRequestQueueFloor(scanCounter))
                                        {
                                            requestsQueue.setSameFloor(scanCounter);
                                            sameFloorPickCounter += 1;
                                        }
                                        else if (requestFloor < getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) <= 10)
                                        {
                                            requestsQueue.setPick(scanCounter);
                                            pickCounter += 1;
                                        }
                                    }
                                }
                                else // DOWN
                                {
                                    if (requestType == 2 )
                                    {
                                        if (currentFloor > getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) > requestFloor)
                                        {
                                            if ( (currentFloor - getRequestQueueFloor(scanCounter))*0.5+timer > getRequestQueueTime(scanCounter) )
                                            {
                                                endTime += identifier(scanCounter);
                                            }
                                        }
                                        else if (getRequestQueueFloor(scanCounter) == requestFloor)
                                        {
                                            requestsQueue.setSameFloor(scanCounter);
                                            sameFloorPickCounter += 1;
                                        }
                                    }
                                    else if (requestType == 0)
                                    {
                                        if (currentFloor > getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) > requestFloor)
                                        {
                                            if ( (currentFloor - getRequestQueueFloor(scanCounter))*0.5+timer > getRequestQueueTime(scanCounter) )
                                            {
                                                endTime += identifier(scanCounter);
                                            }
                                        }
                                        else if (requestFloor == getRequestQueueFloor(scanCounter))
                                        {
                                            requestsQueue.setSameFloor(scanCounter);
                                            sameFloorPickCounter += 1;
                                        }
                                        else if (requestFloor > getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) >= 1)
                                        {
                                                requestsQueue.setPick(scanCounter);
                                                pickCounter += 1;
                                        }
                                    }
                                }
                            }
                        }
                        scanCounter += 1;
                    }
                    /* 执行该指令 */
                    timer = endTime;
                    currentFloor = requestFloor;
                    requestsQueue.setComplete((int)requestIndex);
                    toString(requestIndex, direction);
                    /* 同层捎带处理 同层捎带同质判断 待加入 */
                    int j = 0;
                    for (; sameFloorPickCounter > 0; sameFloorPickCounter--)
                    {
                        while(!requestsQueue.isEmpty(j))
                        {
                            if (getRequestQueueFlag(j) == 4)
                                break;
                            else
                                j++;
                        }
                        requestsQueue.setComplete(j);
                        toString(j, direction);
                        int k = j+1;
                        while (!requestsQueue.isEmpty(j))
                        {
                            if ( getRequestQueueTime(j) > timer+1 )
                                break;
                            else
                                sameJudger(j, k);
                        }
                        j++;
                    }
                    timer += 1;
                }
            }
            else if (requestFlag == 1)
            // 无效
            {
                toString(requestIndex);
            }
//            else if (requestFlag == 3)
//            // 已执行
//            {
//            }
            /* 确认是否捎带队列是否为空 */
            if (pickCounter > 0)
            {
                int j = 0;
                while (!requestsQueue.isEmpty(j))
                {
                    if (getRequestQueueFlag(j) == 2)
                    {
                        pickCounter = 0;
                        info = requestsQueue.get(j);
                        break;
                    }
                    else
                        j++;
                }
            }
            else
            {
                if (!requestsQueue.isEmpty())
                    info = requestsQueue.pop();
                else
                    break;
            }
        }
    }


    @Override
    public int identifier(int index)
    {
//        System.out.println("# identifier:"+index);
        int pickTime = 1;
        double endTime = abs(currentFloor - getRequestQueueFloor(index))*0.5 + timer;
        int direction = (getRequestQueueFloor(index) - currentFloor) > 0 ? 1 : 2; // 1: UP 2: DOWN
        int scanCounter = index+1;
        int sameFloorPickCounter = 0;
        while(!requestsQueue.isEmpty(scanCounter))
        {
            if ( getRequestQueueTime(scanCounter) > endTime+1)
                break;
            else if (getRequestQueueTime(scanCounter) > endTime)
            {
                sameJudger(index, scanCounter);
            }
            else
            {
                if ( !sameJudger(index, scanCounter) )
                {
                    if (direction == 1) //UP
                    {
                        if (getRequestQueueType(index) == 1 || getRequestQueueType(index) == 0)
                        {
                            if (currentFloor < getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) < getRequestQueueFloor(index))
                            {
                                if ((getRequestQueueFloor(scanCounter) - currentFloor) * 0.5 + timer > getRequestQueueTime(scanCounter))
                                {
                                    pickTime += 1;
                                    endTime += identifier(scanCounter);
                                }
                            }
                            else if (getRequestQueueFloor(scanCounter) == getRequestQueueFloor(index))
                            {
                                sameFloorPickCounter += 1;
                                requestsQueue.setSameFloor(scanCounter);
                            }
                        }
//                        else if (getRequestQueueType(index) == 0)
//                        {
//                            if (currentFloor < getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) < getRequestQueueFloor(index))
//                            {
//                                if ( (getRequestQueueFloor(scanCounter) - currentFloor)*0.5+timer > getRequestQueueTime(scanCounter) )
//                                {
//                                    pickTime += 1;
//                                    endTime += identifier(scanCounter);
//                                }
//                            }
//                            else if (getRequestQueueFloor(scanCounter) == getRequestQueueFloor(index))
//                            {
//                                sameFloorPickCounter += 1;
//                                requestsQueue.setSameFloor(scanCounter);
//                            }
//                        }
                    }
                    else // DOWN
                    {
                        if (getRequestQueueType(index) == 2 || getRequestQueueType(index) == 0)
                        {
                            if (currentFloor > getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) > getRequestQueueFloor(index))
                            {
                                if ((currentFloor - getRequestQueueFloor(scanCounter)) * 0.5 + timer > getRequestQueueTime(scanCounter))
                                {
                                    pickTime += 1;
                                    endTime += identifier(scanCounter);
                                }
                            }
                            else if (getRequestQueueFloor(scanCounter) == getRequestQueueFloor(index))
                            {
                                sameFloorPickCounter += 1;
                                requestsQueue.setSameFloor(scanCounter);
                            }
                        }
//                        else if (getRequestQueueType(index) == 0)
//                        {
//                            if (currentFloor > getRequestQueueFloor(scanCounter) && getRequestQueueFloor(scanCounter) > getRequestQueueFloor(index))
//                            {
//                                if ( (currentFloor - getRequestQueueFloor(scanCounter))*0.5+timer > getRequestQueueTime(scanCounter) )
//                                {
//                                    pickTime += 1;
//                                    endTime += identifier(scanCounter);
//                                }
//                            }
//                            else if (getRequestQueueFloor(scanCounter) == getRequestQueueFloor(index))
//                            {
//                                sameFloorPickCounter += 1;
//                                requestsQueue.setSameFloor(scanCounter);
//                            }
//                        }
                    }
                }
            }
            scanCounter += 1;
        }
        timer = endTime;
        currentFloor = getRequestQueueFloor(index);
        requestsQueue.setComplete(index);
        toString(index, direction);
        /* 同层捎带处理 */
        timer += 1;
//        System.out.println("pickTime:"+pickTime);
        return pickTime;
    }

    private boolean sameJudger(int requestIndex, int scanCounter)
    {
        if ( getRequestQueueType(scanCounter)==getRequestQueueType(requestIndex) && getRequestQueueFloor(scanCounter)==getRequestQueueFloor(requestIndex) )
            //操作类型相同且目标楼层相同
        {
            requestsQueue.setSame(scanCounter);
            return true;
        }
        return false;
    }

    public void toString(long index)
    {
        System.out.printf("# 同质请求：输入的第%d条合法请求\n", index+1);
    }

    private void toString(long index, int status)
    {
        if (status == 0)
            System.out.printf("[%d]/(%d,STILL,%.1f)\n", index, currentFloor, timer);
        else if (status == 1)
            System.out.printf("[%d]/(%d,UP,%.1f)\n", index, currentFloor, timer);
        else if (status == -1)
            System.out.printf("[%d]/(%d,DOWN,%.1f)\n", index, currentFloor, timer);
    }

}
