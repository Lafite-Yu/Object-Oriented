public interface IF
{
    void schedule();
    int identifier(int index);
    String toString();
}
